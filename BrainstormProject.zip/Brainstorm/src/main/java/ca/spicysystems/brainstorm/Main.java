package ca.spicysystems.brainstorm;

public class Main {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        System.out.print("Hello World\n");
    }

}
